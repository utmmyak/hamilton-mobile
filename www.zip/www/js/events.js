var fillEventsList = function(){
    $(" <p>Athletics</p><p>Arts</p><p>Admission Tours</p><p>Meetings</p><p>Alumni</p>").appendTo('#eventslist');
};
  
$(document).ready(function(){
    fillEventsList();
});


//var showFilter = function () {
    

//<li><a href="#" data-rel="dialog">Chicken</a></li>
  //              <li><a href="#" data-rel="dialog">Cow</a></li>
    //            <li><a href="#" data-rel="dialog">Duck</a></li>
      //          <li><a href="#" data-rel="dialog">Sheep</a></li>
    
    
//};

//$(document).on("click", "#filterEvents", function(event, ui) { showFilter(event.target.id) });

